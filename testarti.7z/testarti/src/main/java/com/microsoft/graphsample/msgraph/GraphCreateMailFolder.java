package com.microsoft.graphsample.msgraph;

import java.util.Collection;
import java.util.logging.Level;

import com.microsoft.graph.models.extensions.User;
import com.microsoft.graphsample.connect.Constants;
import com.microsoft.graphsample.connect.DebugLogger;

public class GraphCreateMailFolder {
    final private GraphServiceController mGraphServiceController;
    DebugLogger mLogger;
    private String mRecipientEmailAddress;

    public GraphCreateMailFolder() throws CreateFolderException {
        try {
            mGraphServiceController = new GraphServiceController();
            mLogger = DebugLogger.getInstance();

        } catch (Exception e) {
            throw new CreateFolderException("Exception in GraphCreateMailFolder constructor", e);
        }
    }
    
   
    public User getMeUser() throws UserException {
        return mGraphServiceController.getUser();
    }

    public void createMailFolder(String folderNaam) {
        try {
            mGraphServiceController.createMailFolder(folderNaam);
        } catch (CreateFolderException ex) {
            mLogger.writeLog(Level.SEVERE, ex.getMessage(), ex);
        }
    }

    
}
