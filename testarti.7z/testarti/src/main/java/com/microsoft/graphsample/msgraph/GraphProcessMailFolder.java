package com.microsoft.graphsample.msgraph;

import java.util.logging.Level;

import com.microsoft.graph.models.extensions.User;
import com.microsoft.graphsample.connect.Constants;
import com.microsoft.graphsample.connect.DebugLogger;

public class GraphProcessMailFolder {
    final private GraphServiceController mGraphServiceController;
    DebugLogger mLogger;
    private String mRecipientEmailAddress;

    public GraphProcessMailFolder() throws Exception {
        try {
            mGraphServiceController = new GraphServiceController();
            mLogger = DebugLogger.getInstance();

        } catch (Exception e) {
            throw new Exception("Exception in GraphProcessMailFolder constructor", e);
        }
    }

	public void processMailFolder(String folderNaam) {
        try {
            mGraphServiceController.processMailFolder(folderNaam);
        } catch (Exception ex) {
            mLogger.writeLog(Level.SEVERE, ex.getMessage(), ex);
        }
		
	}

}
