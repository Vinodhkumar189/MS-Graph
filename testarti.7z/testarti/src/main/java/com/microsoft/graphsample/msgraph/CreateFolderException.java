package com.microsoft.graphsample.msgraph;

public class CreateFolderException extends Exception {

    private static final long serialVersionUID = 1L;
    public CreateFolderException() { super(); }
    public CreateFolderException(String message) { super(message); }
    public CreateFolderException(String message, Throwable cause) { super(message, cause); }
    public CreateFolderException(Throwable cause) { super(cause); }

}
