package com.microsoft.graphsample.msgraph;

public class DeleteFolderException extends Exception {

    private static final long serialVersionUID = 1L;
    public DeleteFolderException() { super(); }
    public DeleteFolderException(String message) { super(message); }
    public DeleteFolderException(String message, Throwable cause) { super(message, cause); }
    public DeleteFolderException(Throwable cause) { super(cause); }

}
