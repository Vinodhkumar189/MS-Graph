package com.microsoft.graphsample.msgraph;

import java.util.Collection;
import java.util.logging.Level;

import com.microsoft.graph.models.extensions.User;
import com.microsoft.graphsample.connect.Constants;
import com.microsoft.graphsample.connect.DebugLogger;

public class GraphDeleteMailFolder {
    final private GraphServiceController mGraphServiceController;
    DebugLogger mLogger;
    private String mRecipientEmailAddress;

    public GraphDeleteMailFolder() throws DeleteFolderException {
        try {
            mGraphServiceController = new GraphServiceController();
            mLogger = DebugLogger.getInstance();

        } catch (Exception e) {
            throw new DeleteFolderException("Exception in GraphDeleteMailFolder constructor", e);
        }
    }
    
   
    public User getMeUser() throws UserException {
        return mGraphServiceController.getUser();
    }

    public void deleteMailFolder(String folderNaam) {
        try {
            mGraphServiceController.deleteMailFolder(folderNaam);
        } catch (DeleteFolderException ex) {
            mLogger.writeLog(Level.SEVERE, ex.getMessage(), ex);
        }
    }

    
}



