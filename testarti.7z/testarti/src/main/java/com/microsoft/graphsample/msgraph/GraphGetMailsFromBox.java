/*
package com.microsoft.graphsample.msgraph;

import java.util.Collection;
import java.util.logging.Level;

import com.microsoft.graph.models.extensions.User;
import com.microsoft.graphsample.connect.DebugLogger;

public class GraphGetMailsFromBox {
    final private GraphServiceController mGraphServiceController;
    DebugLogger mLogger;

    public GraphGetMailsFromBox() throws Exception {
        try {
            mGraphServiceController = new GraphServiceController();
            mLogger = DebugLogger.getInstance();

        } catch (Exception e) {
            throw new Exception("Exception in GraphGetMailsFromBox constructor", e);
        }
    }

    public User getMeUser() throws UserException {
        return mGraphServiceController.getUser();
    }

    public Collection <?> getMailsFromBox(String foldername) {
        Collection<?> mails = null;

        try {
            mails = mGraphServiceController.getMailsFromBox();
        } catch (Exception ex) {
            mLogger.writeLog(Level.SEVERE, ex.getMessage(), ex);
        }

        return mails;
    }


}
*/