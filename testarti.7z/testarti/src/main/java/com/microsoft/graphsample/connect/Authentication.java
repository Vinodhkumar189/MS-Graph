package com.microsoft.graphsample.connect;

import java.net.MalformedURLException;
// import java.util.Arrays;
        import java.util.Collections;
        import java.util.HashSet;
        import java.util.Set;
        import java.util.function.Consumer;

        import javax.security.auth.login.Configuration.Parameters;

        import com.microsoft.aad.msal4j.AuthorizationCodeParameters;
        import com.microsoft.aad.msal4j.ClientCredentialFactory;
        import com.microsoft.aad.msal4j.ClientCredentialParameters;
        import com.microsoft.aad.msal4j.ConfidentialClientApplication;
        import com.microsoft.aad.msal4j.DeviceCode;
        import com.microsoft.aad.msal4j.DeviceCodeFlowParameters;
        import com.microsoft.aad.msal4j.IAuthenticationResult;
        import com.microsoft.aad.msal4j.IClientCredential;
        import com.microsoft.aad.msal4j.MsalException;
        import com.microsoft.aad.msal4j.PublicClientApplication;
        import com.microsoft.aad.msal4j.SilentParameters;


/**
 * Authentication
 */
public class Authentication  {

    private static String applicationId;
    // Set authority to allow only organizational accounts
    // Device code flow only supports organizational accounts
    private static String authority;
    private static String clientSecret="PH.b3~g8-hDK6Hdm-QHI8.X_N4VEsEEUIq";
    private static String client_id="088cf321-78a2-4938-bf9d-bcf8d3c587b2";

    public static void initialize(String applicationId, String clientSecret) {
      //  Authentication.authority = authority;
       Authentication.applicationId = applicationId;
        Authentication.clientSecret = clientSecret;
        System.out.println("inside initialize");
    }

    public static String getUserAccessToken(String scopes) throws MalformedURLException {
        if (applicationId == null) {
            System.out.println("You must initialize Authentication before calling getUserAccessToken");
            return null;
        }
        Set<String> scopeSet = new HashSet<>();

        Collections.addAll(scopeSet, scopes);
        /*
        PublicClientApplication app;
        try {
            // Build the MSAL application object with
            // app ID and authority
            app = PublicClientApplication.builder(applicationId)
                .authority(authority)
                .build();
        } catch (MalformedURLException e) {
            return null;
        }


        // Create consumer to receive the DeviceCode object
        // This method gets executed during the flow and provides
        // the URL the user logs into and the device code to enter
        Consumer<DeviceCode> deviceCodeConsumer = (DeviceCode deviceCode) -> {
            // Print the login information to the console
            System.out.println(deviceCode.message());
        };

        // Request a token, passing the requested permission scopes
        IAuthenticationResult result = app.acquireToken(
            DeviceCodeFlowParameters
                .builder(scopeSet, deviceCodeConsumer)
                .build()
        ).exceptionally(ex -> {
            System.out.println("Unable to authenticate - " + ex.getMessage());
            return null;
        }).join();
        */


        IClientCredential cred = ClientCredentialFactory.createFromSecret(clientSecret);
        ConfidentialClientApplication app;
        try {
            // Build the MSAL application object for a client credential flow
            app = ConfidentialClientApplication.builder(applicationId, cred ).build();
        } catch (Exception er) {
            System.out.println("Error creating confidential client: ");
            return null;
        }

        IAuthenticationResult result;
        try{
            SilentParameters silentParameters = SilentParameters.builder(scopeSet).build();
            result= app.acquireTokenSilently(silentParameters).join();
        } catch (Exception ex ){
            if (ex.getCause() instanceof MsalException) {

                ClientCredentialParameters parameters =
                        ClientCredentialParameters
                                .builder(scopeSet)
                                .build();

                // Try to acquire a token. If successful, you should see
                // the token information printed out to console
                result = app.acquireToken(parameters).join();
            } else {
                // Handle other exceptions accordingly
                System.out.println("Unable to authenticate = " + ex.getMessage());
                return null;
            }
        }


        if (result != null) {
            // System.out.println("Access Token - " + result.accessToken());
            return result.accessToken();
        }

        return null;
    }
}