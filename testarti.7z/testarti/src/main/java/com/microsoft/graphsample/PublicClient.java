package com.microsoft.graphsample;
/*

import com.gilecode.reflection.ReflectionAccessUtils;
import com.microsoft.graph.models.extensions.User;
import com.microsoft.graphsample.connect.AuthenticationManager;
import com.microsoft.graphsample.connect.DebugLogger;
import com.microsoft.graphsample.msgraph.GraphSendMail;
import com.microsoft.graphsample.msgraph.SendMailException;

import java.io.IOException;
import java.util.Scanner;
import java.util.logging.Level;
*/

import java.io.IOException;

/*import com.microsoft.aad.msal4j.AuthenticationResult;
import com.microsoft.aad.msal4j.PublicClientApplication;
import com.microsoft.aad.msal4j.UserNamePasswordParameters;
import com.nimbusds.oauth2.sdk.http.HTTPResponse;

import java.io.BufferedReader;
//import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Collections;
import java.util.concurrent.ExecutionException;*/

    public class PublicClient {/*

        private final static String APP_ID = "088cf321-78a2-4938-bf9d-bcf8d3c587b2";
      //  private final static String AUTHORITY = "https://login.microsoftonline.com/organizations";
      private final static String AUTHORITY = "https://login.microsoftonline.com/common/oauth2/v2.0/authorize?response_type=code&client_id=088cf321-78a2-4938-bf9d-bcf8d3c587b2&redirect_uri=https%3a%2f%2flogin.microsoftonline.com%2fcommon%2foauth2%2fnativeclient&scope=Files.ReadWrite+openid+User.Read+Mail.Send+Mail.ReadWrite&sso_nonce=AQABAAAAAAAm-06blBE1TpVMil8KPQ41SXiFdZvqSEk48OUQxaCIf8tz9n1wmMMbEUDNSuihHcDiaVPYJrL_4FfcH-3m1OhKLPi7WMa23hKJAtES9BrdHiAA&client-request-id=a5d91a59-d72c-47b0-9a63-9309193b0f06&mscrid=a5d91a59-d72c-47b0-9a63-9309193b0f06";

        public static void main(String[] args) throws InterruptedException, ExecutionException, IOException {

            try (BufferedReader br = new BufferedReader(new InputStreamReader(
                    System.in))) {
                System.out.print("Enter username: ");
                String userName = br.readLine();
                System.out.print("Enter password: ");
                String password = br.readLine();

                // Request access token from AAD
                AuthenticationResult result = getAccessToken(userName, password);

                // Get user info from Microsoft Graph
                String userInfo = getUserInfoFromGraph(result.accessToken());
                System.out.print(userInfo);
            }
        }

        private static AuthenticationResult getAccessToken(String userName, String password)
                throws MalformedURLException, InterruptedException, ExecutionException {

            PublicClientApplication pca = PublicClientApplication.builder(
                    APP_ID).
                    authority(AUTHORITY).build();

            String scopes = "User.Read";
            UserNamePasswordParameters parameters = UserNamePasswordParameters.builder(
                    Collections.singleton(scopes),
                    userName,
                    password.toCharArray()).build();

            AuthenticationResult result = pca.acquireToken(parameters).get();
            return result;
        }

        private static String getUserInfoFromGraph(String accessToken) throws IOException{
            URL url = new URL("https://graph.microsoft.com/v1.0/me");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();

            conn.setRequestMethod("GET");
            conn.setRequestProperty("Authorization", "Bearer " + accessToken);
            conn.setRequestProperty("Accept","application/json");

            int httpResponseCode = conn.getResponseCode();
            if(httpResponseCode == HTTPResponse.SC_OK) {

                StringBuilder response;
                try(BufferedReader in = new BufferedReader(
                        new InputStreamReader(conn.getInputStream()))){

                    String inputLine;
                    response = new StringBuilder();
                    while (( inputLine = in.readLine()) != null) {
                        response.append(inputLine);
                    }
                }
                return response.toString();
            } else {
                return String.format("Connection returned HTTP code: %s with message: %s",
                        httpResponseCode, conn.getResponseMessage());
            }
        }*/
    }


