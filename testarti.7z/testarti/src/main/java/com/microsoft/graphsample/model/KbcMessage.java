package com.microsoft.graphsample.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.microsoft.graph.models.extensions.EventMessage;
import com.microsoft.graph.models.extensions.Message;
//import com.microsoft.graph.models.extensions.Recipient;
import com.microsoft.graph.models.generated.Sensitivity;
import  com.microsoft.graph.models.extensions.Event;



public class KbcMessage extends EventMessage {

    /**
     * The Sensitivity.
     * The possible values are: normal, personal, private, confidential.
     */
    @SerializedName("sensitivity")
    @Expose
    public Sensitivity sensitivity;
}
