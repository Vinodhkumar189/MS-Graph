package com.microsoft.graphsample.msgraph;

import com.microsoft.graph.models.extensions.User;
import com.microsoft.graphsample.connect.DebugLogger;

import java.util.Collection;
import java.util.logging.Level;

public class GraphGetMailFolders {
    final private GraphServiceController mGraphServiceController;
    DebugLogger mLogger;

    public GraphGetMailFolders() throws GetFoldersException {
        try {
            mGraphServiceController = new GraphServiceController();
            mLogger = DebugLogger.getInstance();

        } catch (Exception e) {
            throw new GetFoldersException("Exception in GraphGetMailFolders constructor", e);
        }
    }

    public User getMeUser() throws UserException {
        return mGraphServiceController.getUser();
    }

    public Collection <?> getMailFolders(String sendAddress) {
        Collection<?> mailFolders = null;

        try {
            mailFolders = mGraphServiceController.getMailFolders();
        } catch (GetFoldersException ex) {
            mLogger.writeLog(Level.SEVERE, ex.getMessage(), ex);
        }

        return mailFolders;
    }

}
