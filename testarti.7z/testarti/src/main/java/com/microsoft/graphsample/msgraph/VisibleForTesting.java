package com.microsoft.graphsample.msgraph;

public @interface VisibleForTesting {
}
