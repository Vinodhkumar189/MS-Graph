package com.microsoft.graphsample.msgraph;

public class GetFoldersException extends Exception {
    private static final long serialVersionUID = 1L;
    public GetFoldersException() { super(); }
    public GetFoldersException(String message) { super(message); }
    public GetFoldersException(String message, Throwable cause) { super(message, cause); }
    public GetFoldersException(Throwable cause) { super(cause); }
}
