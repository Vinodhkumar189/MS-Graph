package com.microsoft.graphsample;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

//import java.util.Base64;

public class RestRun {

    public static void main(String args[]) throws Exception {
    System.out.println("remo");
   /* String authorizationUrl ="https://login.microsoftonline.com/common/oauth2/v2.0/authorize?response_type=code&client_id=088cf321-78a2-4938-bf9d-bcf8d3c587b2&redirect_uri=https%3a%2f%2flogin.microsoftonline.com%2fcommon%2foauth2%2fnativeclient&scope=Files.ReadWrite+openid+User.Read+Mail.Send+Mail.ReadWrite&sso_nonce=AQABAAAAAAAm-06blBE1TpVMil8KPQ41kJfmoMaJtL4buLfrmd9KbZK7ACugRHRULhz0w-hVkT4f14t5O-DDzrwuALzsrPdR11GElvKwOSlkV_bEtFVWNCAA&client-request-id=5f0d3309-56f1-4d7d-852d-fb39296a1c0c&mscrid=5f0d3309-56f1-4d7d-852d-fb39296a1c0c";
        URL obj = new URL(authorizationUrl);
        HttpURLConnection con = (HttpURLConnection) obj.openConnection();
        con.setRequestMethod("GET");

        // con.setRequestProperty("User-Agent", USER_AGENT);
        int responseCode = con.getResponseCode();
        String encoded = Base64.encode(username+":"+password);
        con.setRequestProperty("Authorization", "Basic "+encoded);
        System.out.println("GET Response Code :: " + responseCode);
        if (responseCode == HttpURLConnection.HTTP_OK) { // success
            BufferedReader in = new BufferedReader(new InputStreamReader(
                    con.getInputStream()));
            String inputLine;
            StringBuffer response = new StringBuffer();

            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();

            // print result
            System.out.println(response.toString());
        } else {
            System.out.println("GET request not worked");
        }
*//*
        HttpClient client = HttpClient.newHttpClient();
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(uri))
                .build();

        HttpResponse<String> response =
                client.send(request, BodyHandlers.ofString());

        System.out.println(response.body());*/
    }
}
