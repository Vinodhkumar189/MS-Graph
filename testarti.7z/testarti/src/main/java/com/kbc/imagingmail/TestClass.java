package com.kbc.imagingmail;

/*import org.apache.oltu.oauth2.client.OAuthClient;
import org.apache.oltu.oauth2.client.URLConnectionClient;
import org.apache.oltu.oauth2.client.request.OAuthClientRequest;
import org.apache.oltu.oauth2.client.response.OAuthJSONAccessTokenResponse;
import org.apache.oltu.oauth2.common.OAuth;
import org.apache.oltu.oauth2.common.message.types.GrantType;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;*/
import java.util.Calendar;
import java.util.Date;

import java.text.DateFormat;
import java.text.SimpleDateFormat;


public class TestClass {
    public Date getStartDate() {
        return startDate;
    }

    public void  setStartDate(Date startDate) {
        this.startDate = startDate;
    }
     static Date startDate;
    public  static void main(String[] args) {

        System.out.println("remo1");
        Calendar myDate = Calendar.getInstance();
        //c.setTime(dateobj);
        int dayOfWeek = myDate.get (Calendar.DAY_OF_WEEK);
        System.out.println("dayOfWeek : "+dayOfWeek);
        boolean isWeekday = ((dayOfWeek >= Calendar.MONDAY) && (dayOfWeek <= Calendar.FRIDAY));
        if(isWeekday)
            System.out.println("true");
            else
        System.out.println("false");
       /* DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
        Date dateobj = new Date();
        //dateobj="02/07/2020";
        System.out.println(df.format(dateobj));

        Calendar c = Calendar.getInstance();
        c.setTime(dateobj);
        int weekNr = c.get(Calendar.WEEK_OF_YEAR);
        int yearNr = c.get(Calendar.YEAR);
        int monthNr = c.get(Calendar.MONTH) + 1;   // januari = 0
        int dayNr = c.get(Calendar.DAY_OF_MONTH);
        int dayOfWeek = c.get(Calendar.DAY_OF_WEEK);
        System.out.println("dayOfWeek:" + weekNr + " : dayOfWeek1 :" + yearNr);
        System.out.println("monthNr:" + monthNr + " : dayNr :" + dayNr + " : " + dayOfWeek);
        if (dayOfWeek == 5) {
            dayOfWeek =7;
            System.out.println("monthNr:" + monthNr + " : dayNr :" + dayNr + " : " + dayOfWeek);
        }*/
    }
}