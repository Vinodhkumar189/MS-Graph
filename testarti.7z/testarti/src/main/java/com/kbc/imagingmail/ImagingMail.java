package com.kbc.imagingmail;

import com.gilecode.reflection.ReflectionAccessUtils;
import com.microsoft.graph.models.extensions.User;
import com.microsoft.graph.requests.extensions.MailFolderCollectionRequestBuilder;
import com.microsoft.graphsample.connect.AuthenticationManager;
import com.microsoft.graphsample.connect.DebugLogger;
import com.microsoft.graphsample.msgraph.CreateFolderException;
import com.microsoft.graphsample.msgraph.GetFoldersException;
import com.microsoft.graphsample.msgraph.GraphCreateMailFolder;
import com.microsoft.graphsample.msgraph.GraphDeleteMailFolder;
import com.microsoft.graphsample.msgraph.GraphGetMailFolders;
import com.microsoft.graphsample.msgraph.GraphProcessMailFolder;
import com.microsoft.graphsample.msgraph.GraphSendMail;
import com.microsoft.graphsample.msgraph.SendMailException;



import java.io.IOException;
import java.util.*;
import java.util.logging.Level;

import javax.lang.model.element.Element;

public class ImagingMail {
    protected static AuthenticationManager authenticationManager = null;
    DebugLogger mLogger;
    Scanner mScanner;
    
    String commando;
    String mailAdres;
    String mailCcAdres;
    String mailBccAdres;
    String mailOnderwerp;
    String mailBody;
    String mailAttachment;
    String folderNaam;
    Collection <?> folderLijst;

    public ImagingMail() throws IOException {
        mLogger = DebugLogger.getInstance();
        mScanner = new Scanner(System.in, "UTF-8");
    }

    public static void main(String args[]) throws Exception {
        ImagingMail imagingMail = new ImagingMail();
        try {
        	
        	
        	// Voorbeeld versturen mail. adres, cc, bcc, subject, body, attachment
          //  imagingMail.execute("sendmail", "saravanakumar.appadurai@kbc.be", "", "saravanakumar.appadurai@kbc.be", "testSubject", "body", "c:/Saravanan/Overdraft.docx");
            imagingMail.execute("sendmail", "saravanakumar.appadurai@kbc.be", "", "saravanakumar.appadurai@kbc.be", "testSubject", "body", "c:/Saravanan/testMail.pdf");

          	// Voorbeeld maken van een map.
            //imagingMail.execute("createfolder", "mijn_folder12b");

          	// Voorbeeld verwijderen van een map.
            //imagingMail.execute("deletefolder", "mijn_folder12b");

        	// Voorbeeld opvragen lijst van mailmappen.
            
            Collection <?> mijnFolderLijst = new LinkedList<String>();
            imagingMail.execute("getfolders", mijnFolderLijst);
          	//for (Object o: mijnFolderLijst) System.out.println(o);          	
          	/*
          	 * Voorbeeld van output: 
             *    Archief
             *    Concepten
             *    Gesprekgeschiedenis
             *    mijn_folder
             *    mijn_folder12
             *    Ongewenste e-mail
             *    Postvak IN
             *    Postvak UIT
             *    testmap
             *    Verwijderde items
          	 */
          	
        	// Voorbeeld verwerken emails van een bepaalde folder.
          	//imagingMail.execute("processfolder", "mijn_folder");
          	
        } catch(Exception ex) {
            System.out.println(ex.getMessage());
        } finally {
            imagingMail.mScanner.close();
        }
    }

    private void execute(String commando) throws Exception
    {
        startConnect(commando);    	
    }
    private void execute(String commando, String par1) throws Exception
    {
        if (commando.equals("createfolder")) folderNaam = new String(par1);
        if (commando.equals("deletefolder")) folderNaam = new String(par1);
        if (commando.equals("processfolder")) folderNaam = new String(par1);
        startConnect(commando);    	
    }
    private void execute(String commando, Collection <?> collectie) throws Exception
    {
        startConnect(commando);
        if (commando.equals("getfolders"))
        {
        	Iterator<?> iterator = folderLijst.iterator();
            while (iterator.hasNext()) ((LinkedList)collectie).add(iterator.next());
        }
    }
    private void execute(String commando, String par1, String par2) throws Exception
    {
        startConnect(commando);    	
    }
    public void execute(String commando, String par1, String par2, String par3, String par4, String par5, String par6) throws Exception
    {
    	if (commando.equals("sendmail"))
    	{
    		mailAdres = new String(par1);
    		mailCcAdres = new String(par2);
    		mailBccAdres = new String(par3);
            mailOnderwerp = new String(par4);
            mailBody = new String(par5);
            mailAttachment = new String(par6);
    	}
        startConnect(commando);    	
    }
    
    
    /*
     *
     * 
     * 
     * 
     * 
     */
    private void startConnect(String commando) throws Exception {
        System.out.println("Welcome to Imaging Mail!");
        System.out.println(commando);

        if (ImagingMail.authenticationManager == null)
        {
            //If this call is removed, functionality of the sample is not
            //affected. The call simply suppresses warnings generated from json deserialization
            //in the Graph SDK
            ReflectionAccessUtils.suppressIllegalReflectiveAccessWarnings();
            authenticationManager = AuthenticationManager.getInstance();
            authenticationManager.connect(mScanner);
        }

        if (commando.equals("sendmail")) startSendMail();
        if (commando.equals("getfolders")) startGetFolders();
        if (commando.equals("createfolder")) startCreateFolder();
        if (commando.equals("deletefolder")) startDeleteFolder();
        if (commando.equals("processfolder")) startProcessFolder();
    }

    /**
     * Prompts user for email address to send mail and prompts
     * for additional email address to send mail. Continues until
     * user declines to send a mail.
     *
     * @throws Exception
     */
    private void startSendMail() throws Exception {
        GraphSendMail graphSendMail = new GraphSendMail();
        User meUser = null;
        try {
            meUser = graphSendMail.getMeUser();

            String  preferredName   = meUser.displayName;
            Boolean sendAnotherMail = true;
            /*
            while (sendAnotherMail) {
                System.out.println(
                        "Hello, " + preferredName + ". Would you like to send an email to yourself or someone else?");
                String sendMailAddress = "";
                sendMailAddress = getUserInput("Enter the address to which you'd like to send a message. " +
                                      "If you enter nothing, the message will go to your address");
                sendMailAddress = sendMailAddress.isEmpty() ? meUser.mail : sendMailAddress;
                graphSendMail.sendMail(sendMailAddress);

                String sendAnotherYN = getUserInput("\nEmail sent! \n Want to send another message? Type 'y' for yes and any other key to exit.");
                if (sendAnotherYN.isEmpty()) {
                    sendAnotherMail = false;
                }
                else {
                    sendAnotherMail = (sendAnotherYN.charAt(0) == 'y') ? true : false;
                }
            }*/
            //graphSendMail.sendMail("geert.van.espen@kbc.be");
            graphSendMail.sendMail(mailAdres, mailCcAdres, mailBccAdres, mailOnderwerp, mailBody, mailAttachment);
            
            if (ImagingMail.getAuthenticationManager() != null) {
                ImagingMail.getAuthenticationManager().disconnect();
            }

        } catch (SendMailException ex) {
            mLogger.writeLog(Level.SEVERE, ex.getMessage(), ex);
            return;
        } catch (Exception e) {
            mLogger.writeLog(Level.SEVERE, "Exception in startSendMail ", e);
        }

    }

    /**
     * GVE
     * Gets folders in mailbox of user "me" and puts them in a collection.
     *
     * @throws Exception
     */
    private void startGetFolders() throws Exception {
        GraphGetMailFolders graphGetMailFolders = new GraphGetMailFolders();
        try {
        	User meUser = graphGetMailFolders.getMeUser();
            folderLijst = graphGetMailFolders.getMailFolders("");
            
            if (ImagingMail.getAuthenticationManager() != null) {
                ImagingMail.getAuthenticationManager().disconnect();
            }

        } catch (GetFoldersException ex) {
            mLogger.writeLog(Level.SEVERE, ex.getMessage(), ex);
            return;
        } catch (Exception e) {
            mLogger.writeLog(Level.SEVERE, "Exception in startGetFolders ", e);
        }        
    }

    /**
     * GVE
     * Creates mailfolder "folderNaam" for user "me".
     *
     * @throws Exception
     */
    private void startCreateFolder() throws Exception {
        GraphCreateMailFolder graphCreateMailFolder = new GraphCreateMailFolder();
        User meUser = null;
        try {
            meUser = graphCreateMailFolder.getMeUser();
            graphCreateMailFolder.createMailFolder(folderNaam);
            
            if (ImagingMail.getAuthenticationManager() != null) {
                ImagingMail.getAuthenticationManager().disconnect();
            }

        } catch (CreateFolderException ex) {
            mLogger.writeLog(Level.SEVERE, ex.getMessage(), ex);
            return;
        } catch (Exception e) {
            mLogger.writeLog(Level.SEVERE, "Exception in startCreateFolder ", e);
        }
    }
    
    /**
     * GVE
     * Deletes mailfolder "folderNaam" of user "me".
     *
     * @throws Exception
     */
    private void startDeleteFolder() throws Exception {
        GraphDeleteMailFolder graphDeleteMailFolder = new GraphDeleteMailFolder();
        User meUser = null;
        try {
            meUser = graphDeleteMailFolder.getMeUser();
            graphDeleteMailFolder.deleteMailFolder(folderNaam);
            
            if (ImagingMail.getAuthenticationManager() != null) {
                ImagingMail.getAuthenticationManager().disconnect();
            }

        } catch (CreateFolderException ex) {
            mLogger.writeLog(Level.SEVERE, ex.getMessage(), ex);
            return;
        } catch (Exception e) {
            mLogger.writeLog(Level.SEVERE, "Exception in startCreateFolder ", e);
        }
    }
    
    /**
     * GVE
     * Gets mails in mailboxfolder "folderNaam" of user "me" and moves them to the processing folder (Postvak IN/Processing folder) of user "me".
     *
     * @throws Exception
     */
    private void startProcessFolder() throws Exception {
        GraphProcessMailFolder graphProcessMailFolder = new GraphProcessMailFolder();
        //User meUser = null;
        try {
            //meUser = graphProcessMailFolder.getMeUser();
            graphProcessMailFolder.processMailFolder(folderNaam);
            
            if (ImagingMail.getAuthenticationManager() != null) {
                ImagingMail.getAuthenticationManager().disconnect();
            }

        } catch (Exception e) {
            mLogger.writeLog(Level.SEVERE, "Exception in startProcessFolder ", e);
        }
    }
    
    public static AuthenticationManager getAuthenticationManager() throws IOException {

        try {
            return AuthenticationManager.getInstance();
        } finally {

        }
    }

    public String getUserInput(String prompt) throws Exception {
        System.out.println(prompt);
        final String code = mScanner.nextLine();
        return code;
    }
}
